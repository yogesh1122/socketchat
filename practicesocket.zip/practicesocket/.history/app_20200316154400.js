const express = require('express');
const app = express();



//set the template engine ejs
app.set('view engine', 'ejs')

//middlewares
app.use(express.static('public'))


// app.get('/work',async(req,res)=>
// {
// 	res.send('ok connection')
// })


app.get('/', (req, res) => {
	res.render('index')
})

app.get('/webchat', (req,res)=>
{
	res.render('login');
})

server = app.listen(3000,()=>{console.log('server listing on 3000')})



//socket.io instantiation
const io = require("socket.io")(server)


//listen on every connection
io.on('connection', (socket) => {
	console.log('New user connected')

	//default username
	socket.username = "Anonymous"

    //listen on change_username
    socket.on('change_username', (data) => {
	   console.log(data);
		socket.username = data.username
    })

    //listen on new_message
    socket.on('new_message', (data) => {
        //broadcast the new message
        io.sockets.emit('new_message', {message : data.message, username : socket.username});
    })

    //listen on typing
    socket.on('typing', (data) => {
    	socket.broadcast.emit('typing', {username : socket.username})
	})

	//login
	socket.on('login',(data)=>{

		console.log('login IN sucess');
		console.log(data.loginMsg);
		io.sockets.emit('login',{message:data.loginMsg})


		// require('./middleware/login')(app)

		//loginmid();

	})
})





