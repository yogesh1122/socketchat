const express = require('express');

const app= express();

let mid=

 module.exports=(app)=>{
	app.use((req,res,next)=>
	{
		res.render('index')
		next()
	})
 }