const express = require('express');

const app= express();
let mid=app.use((req,res,next)=>
{
	res.render('index')
	next()
})

 module.exports={ mid}