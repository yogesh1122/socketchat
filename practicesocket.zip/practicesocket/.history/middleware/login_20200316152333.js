const express = require('express');

const app= express();



 module.exports=fuction logmid(app)
 {
	app.use((req,res,next)=>
	{
		res.render('index')
		next()
	})
 }